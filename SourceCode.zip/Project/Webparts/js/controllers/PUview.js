PPAC.controller("PUviewCtrl", function($scope, $rootScope, $sce,$filter, $location,$routeParams,$timeout, Hyper, SITE_SETTINGS) {
  console.log("PUviewCtrl");

  var itemId = 80;
  url = "/_api/web/lists/getbytitle('PPAC Request')/items(" + itemId + ")";

  Hyper.get(url).success(function(response) {
    $scope.PPACNo = response.d.PPACNo;
    $scope.proposer = response.d.proposer;
    $scope.rational = response.d.rational;
    $scope.ratMod = $sce.trustAsHtml(response.d.modi);
    $scope.detChange = response.d.changes;
    $scope.comp = response.d.comp;
    $scope.req = response.d.reqType;
    $scope.prodName = response.d.prod;
    $scope.brfDes = response.d.desc;
















    var documentLibraryName = "Notes";
    var documentLibraryUrl = "/_api/web/lists/getbytitle('" + documentLibraryName + "')/items?$filter=FSObjType eq 0&$select=FileLeafRef";

    Hyper.get(documentLibraryUrl).success(function(response) {
      var files = response.d.results;
      console.log("Number of files in the document library '" + documentLibraryName + "': " + files.length);
      console.log("Files in the document library '" + documentLibraryName + "':");
      for (var i = 0; i < files.length; i++) {
        console.log(files[i].FileLeafRef);
      }

      var folderName = $scope.PPACNo;
      var folderUrl = "/_api/web/lists/getbytitle('" + documentLibraryName + "')/items?$select=FileLeafRef,FileRef&$filter=startswith(FileRef, '/" + documentLibraryName + "/" + folderName + "/')";

      Hyper.get(folderUrl).success(function(response) {
        var files = response.d.results;
        console.log("Number of files in the folder '" + folderName + "': " + files.length);
        console.log("Files in the folder '" + folderName + "':");
        if (files.length === 0) {
          console.log("No files found in folder " + folderName);
        } else {
          for (var i = 0; i < files.length; i++) {
            console.log(files[i].FileLeafRef);
          }
        }
      }).error(function(error) {
        console.log(error);
        console.log("Folder not found: " + folderName);
      });
    }).error(function(error) {
      console.log(error);
      console.log("Document library not found: " + documentLibraryName);
    });
  });
});


/*
PPAC.controller("PUviewCtrl", function($scope, $rootScope, $filter, Hyper, SITE_SETTINGS) {
	console.log("PUviewCtrl");
var itemId = 65;
  url = "/_api/web/lists/getbytitle('PPAC Request')/items(" + itemId + ")";
  Hyper.get(url)
  .success(function(response){
  $scope.PPACNo = response.d.PPACNo; 

 var folderName = $scope.PPACNo;
var documentLibraryName = "Notes";
var folderUrl = "/_api/web/lists/getbytitle('" + documentLibraryName + "')/items?$select=FileLeafRef,FileRef&$filter=startswith(FileRef, '/" + documentLibraryName + "/" + folderName + "/')";

Hyper.get(folderUrl).success(function(response) {
  console.log(response);

  var files = response.d.results;
  console.log(files.length);

  if (files.length === 0) {
    console.log("No files found in folder " + folderName);
  } else {
    for (var i = 0; i < files.length; i++) {
      console.log(files[i].FileLeafRef);
    }
  }
}).error(function(error) {
  console.log(error);
  console.log("Folder not found in document library");
});

console.log($scope.PPACNo);
  });

});*/