var PPAC = angular.module("PPAC", ['ngRoute', 'ngSanitize', 'ui.bootstrap','ngAnimate']);

PPAC.constant("SITE_SETTINGS", {
	site_url:_spPageContextInfo.siteServerRelativeUrl+"/",
    GlobalDateFormat:"dd/MM/yyyy",
     userGroups: {
   	PU: 52, 
    BUHead:41, //BU Head
    RU : 53,
    ORM : 54 
   },
   userInfo: {
   	id: _spPageContextInfo.userId,
   	name: _spPageContextInfo.userDisplayName,
   	email: _spPageContextInfo.userLoginName,
   	image:_spPageContextInfo.userPhotoCdnBaseUrl,
   	roles:[],
    loginRole:null
   },   
   initStatus:0
});

PPAC.config(function($routeProvider) {
    console.log("Inside app.js")
    $routeProvider
    .when("/",{
		templateUrl :"../Style%20Library/PPAC/Webparts/pages/switch_role.html",
        resolve :{
			resolvedVal:["$timeout","$location", "SITE_SETTINGS",function($timeout, $location, SITE_SETTINGS){
				
				var dataTimeout = $timeout(function() {
					if (SITE_SETTINGS.initStatus !=0) {
						if(SITE_SETTINGS.initStatus == 1){
							return true;
						}
						else{
							$location.path("/error");
						}
						$timeout.cancel(dataTimeout);
					}
				}, 500);
				
			}]
		}
	})
    // .when("/", {
    //     // redirectTo:"/test"
        
    // })
    .when("/test", {
        templateUrl: "../Style%20Library/PPAC/Webparts/pages/test.html"
    })    
    .when("/EmployeeDetails", {
        templateUrl: "../Style%20Library/PPAC/Webparts/pages/EmployeeDetails.html"
    })    
       
	   .when("/CreateRequestPU", {
        templateUrl: "../Style%20Library/PPAC/Webparts/pages/CreateRequestPU1.html"
    })
    
    .when("/request/:Id", {
        templateUrl: "../Style Library/PPAC/Webparts/pages/ViewRequest/ViewRequest.html"
    }) 
	 .when("/request1", {
        templateUrl: "../Style Library/PPAC/Webparts/pages/ViewRequest/ViewReq.html"
    }) 
	
       .when("/PUview", {
        templateUrl: "../Style%20Library/PPAC/Webparts/pages/PUview.html"
    }) 
       .when("/RUscreen", {
        templateUrl: "../Style%20Library/PPAC/Webparts/pages/RUscreen.html"
    }) 
       .when("/ORMConfig", {
        templateUrl: "../Style%20Library/PPAC/Webparts/pages/ORMConfig.html"
    }) 
	      .when("/ORM_Main", {
        templateUrl: "../Style%20Library/PPAC/Webparts/pages/ORM/ORM_Main.html"
    }) 
	
	      .when("/Meeting_summary", {
        templateUrl: "../Style%20Library/PPAC/Webparts/pages/ORM/Meeting_summary.html"
    }) 
		      .when("/Create_meeting", {
        templateUrl: "../Style%20Library/PPAC/Webparts/pages/ORM/Create_meeting.html"
    }) 
			      .when("/PU_Dashboard", {
        templateUrl: "../Style%20Library/PPAC/Webparts/pages/PU/PU_Dashboard.html"
    }) 
				      .when("/RU_Dashboard", {
        templateUrl: "../Style%20Library/PPAC/Webparts/pages/RU/RU_Dashboard.html"
    }) 
					      .when("/BUH_Dashboard", {
        templateUrl: "../Style%20Library/PPAC/Webparts/pages/BUH/BUH_Dashboard.html"
    }) 

    .when("/404", {
        template: "<div class='text-center'><h1>Error:404</h1><h2>Page not found.<br/> Kindly contact your Administrator for any futher queries regarding this site access.</h2><div>",
    }) 
	.otherwise({
        template : "<h1>Page not found</h1><p>Page you are looking for is not found</p>"
    });
})

PPAC.controller("PPACMainCtrl", function($scope, $rootScope, $filter,$location, Hyper, SITE_SETTINGS, $q) {
	console.log("PPACMainCtrl");
	$scope.profileName= _spPageContextInfo.userDisplayName;
	$scope.profilePic="../_layouts/15/userphoto.aspx?accountname="+_spPageContextInfo.userLoginName;
    $scope.getCurrentUserGroupDetails = function(path){
		var url='/_api/web/currentuser/?$expand=groups';
		Hyper.get(url)
		.success(function (data, status, headers, config) {  
			if(status==200){
				var temp=(data.d!=undefined)?data.d:data;
				var groups=(temp.Groups.results!=undefined)?temp.Groups.results:temp.Groups;
				if(groups.length>0){
					var groupIds = SITE_SETTINGS.userGroups;
					
					SITE_SETTINGS.userInfo.roles = [];	
					
					angular.forEach(groups,function(val,i){
						//console.log(val);
        				if(val.Id == groupIds.PU) {
							SITE_SETTINGS.userInfo.roles.push("PU");	
						}
                        else if(val.Id == groupIds.BUHead) {
							SITE_SETTINGS.userInfo.roles.push("BUHead");	
						}
                        else if(val.Id == groupIds.RU) {
							SITE_SETTINGS.userInfo.roles.push("RU");	
						}
                        else if(val.Id == groupIds.ORM) {
							SITE_SETTINGS.userInfo.roles.push("ORM");	
						}						
					});
                    SITE_SETTINGS.initStatus = 1;
                    if (SITE_SETTINGS.userInfo.roles.length>1) {
						sessionStorage.setItem("SITE_SETTINGS", JSON.stringify(SITE_SETTINGS));
					$location.path("/");
				} else {
					SITE_SETTINGS.userInfo.loginRole= SITE_SETTINGS.userInfo.roles[0];
					sessionStorage.setItem("SITE_SETTINGS", JSON.stringify(SITE_SETTINGS));
				}
				}
				else{
					SITE_SETTINGS.initStatus = -1;
					$rootScope.isLoading = false;
					$location.path("/access-denied");
				}
				
			}
		}).error(function (data, status, headers, config) {  
			console.log("Error - " , data, status, headers, config);
			SITE_SETTINGS.initStatus = -1;
			$rootScope.isLoading = false;
       		$location.path("/error");
		});
    }
     $scope.getCurrentUserGroupDetails();

});

