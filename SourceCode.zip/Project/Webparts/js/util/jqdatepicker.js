YesWheels.directive('jqdatepicker', function () {
    return {
        restrict: 'A',
		scope: {
			model:'=ngModel',
            min:"@min",
            max:"@max",
        },

        require: 'ngModel',
         link: function (scope, element, attrs, ngModelCtrl) {
            element.datepicker({
                buttonImageOnly: true,
                buttonText: "Select date",
                showOn: "button",
                minDate: (moment(scope.min).isValid())?new Date(scope.min):0,
                buttonImage: "../Style%20Library/images/calendar.gif",
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd/mm/yy',
				beforeShow: function(){
		            if(moment(attrs["minDate"],'YYYY-MM-DDThh:mm:ssz').isValid())
		                $(element).datepicker('option', 'minDate', moment(attrs["minDate"],'YYYY-MM-DDThh:mm:ssz').toDate());
		              
		            if(moment(attrs["maxDate"],'YYYY-MM-DDThh:mm:ssz').isValid())
		                $(element).datepicker('option', 'maxDate',  moment(attrs["maxDate"],'YYYY-MM-DDThh:mm:ssz').toDate());
		          }
          
            }).focus(function () {
                element.datepicker("show");
            });
			console.log("attrs",attrs)

        }
    };
});