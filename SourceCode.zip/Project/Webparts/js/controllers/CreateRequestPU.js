PPAC.controller("createReCtrl", function($scope, $rootScope, $filter,$routeParams, $timeout, Hyper, SITE_SETTINGS) {
	console.log("CreateRECtrl");

	$scope.loginuser = SITE_SETTINGS.userInfo.name;
	$scope.uniqueId = null; 

generateUniqueID(function(uniqueID){
    $scope.uniqueId = uniqueID; 
});


	$(document).ready(function() {
  // Listen for changes on the radio buttons
  $('input[type=radio]').on('change', function() {
    var checkedRequest = [];
    
    // Get an array of the checked radio buttons
    $('input[type=radio]:checked').each(function() {
      checkedRequest.push($(this).val());
    });

    // If no radio button is selected, hide all info cards
    if (checkedRequest.length === 0) {
      $('.info-card').hide();
    } else {
      // Loop through each info card
      $('.info-card').each(function() {
        var cardValue = $(this).attr('value');
        if($.inArray(cardValue, checkedRequest) !== -1){
          $(this).show();
        } else {
          $(this).hide();
        }
      });
    }
  });
  

  // Check the initially checked radio button(s)
  $('input[type=radio]').trigger('change');
});
  
const fileUploadInput = document.querySelector('#file-upload');
const mainFileContainer = document.querySelector('#main-file-container');
let isUploading = false;

fileUploadInput.addEventListener('change', function() {
   // If already uploading, return
   if (isUploading) {
      return;
   }
   // Set isUploading to true
   isUploading = true;
	
   const file = this.files[0];
   const mainFileDiv = document.createElement('div');
   mainFileDiv.className = 'main-file d-flex ms-2';
   const subFileDiv = document.createElement('div');
   subFileDiv.className = 'sub-file';
   const fileIcon = document.createElement('i');
   fileIcon.className = 'bi bi-file-earmark';
   fileIcon.addEventListener('click', function() {
    // Trigger the download action
    const url = URL.createObjectURL(file);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  });
   subFileDiv.appendChild(fileIcon);
   mainFileDiv.appendChild(subFileDiv);
   const fileNameParagraph = document.createElement('p');
   fileNameParagraph.className = 'p-2';
   fileNameParagraph.textContent = file.name;
   mainFileDiv.appendChild(fileNameParagraph);
   const xIcon = document.createElement('i');
   xIcon.className = 'bi bi-x';
   xIcon.addEventListener('click', function() {
      mainFileDiv.remove();
      fileUploadInput.value = null;
   });
   mainFileDiv.appendChild(xIcon);
   // Remove any existing preview before adding the new one
   mainFileContainer.innerHTML = '';
   mainFileContainer.appendChild(mainFileDiv);

   // Reset isUploading to false
   isUploading = false;
});


/*
const fileUploadInput = document.querySelector('#file-upload');
const mainFileContainer = document.querySelector('#main-file-container');

fileUploadInput.addEventListener('change', function() {
	
   const file = this.files[0];
   const mainFileDiv = document.createElement('div');
   mainFileDiv.className = 'main-file d-flex ms-2';
   const subFileDiv = document.createElement('div');
   subFileDiv.className = 'sub-file';
   const fileIcon = document.createElement('i');
   fileIcon.className = 'bi bi-file-earmark';
   subFileDiv.appendChild(fileIcon);
   mainFileDiv.appendChild(subFileDiv);
   const fileNameParagraph = document.createElement('p');
   fileNameParagraph.className = 'p-2';
   fileNameParagraph.textContent = file.name;
   mainFileDiv.appendChild(fileNameParagraph);
   const xIcon = document.createElement('i');
   xIcon.className = 'bi bi-x';
   xIcon.addEventListener('click', function() {
      mainFileDiv.remove();
      fileUploadInput.value = null;
   });
   mainFileDiv.appendChild(xIcon);
   mainFileContainer.appendChild(mainFileDiv);
	
});*/



$scope.id=1;
$scope.onFileSelected = function(index) {
		$scope.spinner=true;
		
		var element = document.getElementById('file-upload');
		
		index = index || 0;
		var file = element.files[index];
		
		if (file == undefined) {
			return null;
		} else if (file == null) {
			return null;
		}
		
		var fileName =  file.name;

		Hyper.uploadFileInstance('Notes', fileName, file)
		.then(function(response) {
	        //console.log("success",response);
            var docId = response.ListItemAllFields.ID;
            
            if ($scope.id != null && $scope.id!=undefined) {
            	$scope.updateDocLkp($scope.id, docId, index);
            } else {
            	$scope.formData.documents.push({
            		Id:docId,
            		File: {
            			ServerRelativeUrl:response.ServerRelativeUrl,
            			Name: response.Name
            		}
            	});
            	$scope.unLinkedFiles.push(docId);
            	index++;
            	if (index <element.files.length) {
	               $scope.onFileSelected(index);
	            } else {	            	
	            	$("#attachments").val("");
                alert('File(s) uploaded successfully');
                $scope.spinner =false;
	            }
            }  
	    }, function(er) {
	        $scope.spinner=false;
	        alert('Something went wrong, Please try again later');
	    })
	}

function generateUniqueID(callback){
    Hyper.get("_api/web/lists/getByTitle('PPAC Request')/items")
    .success(function(response){
        var highestNumber = 100;
        angular.forEach(response.d.results, function (item) {
            var columnName = "PPACNum"; 
            var id = item[columnName];
            if (id) {
                var number = parseInt(id.match(/\d+$/)[0]);
                if (number > highestNumber) {
                    highestNumber = number;
                }
            }
        });
        var uniqueID = "PPAC" + (highestNumber + 1).toString();
        console.log(uniqueID);
        callback(uniqueID);
    });
}

$scope.SubmitReq = function () {

	const selectedRadio = document.querySelector('input[name="inlineRadioOptions"]:checked');
	var selectedRadioName = selectedRadio ? selectedRadio.value : null;
	if(selectedRadioName === '1'){
		selectedRadioName = "New To Bank";
	}
	console.log(selectedRadioName);
	

  // Get the values from the HTML elements
  const rational = document.getElementById('RationalNTB').value;
  const ppacNumber = document.getElementById('PPACNo').value;
  const proposingUnit = document.getElementById('PUName').value;
  const productName = document.getElementById('ProductName').value;
  const typeOfNote = document.getElementById('NoteType').value;
  const detailsOfChanges = document.getElementById('DetChanges').value;
  const rationalOfModification = document.getElementById('RationalModification').value;
  const complexityOrNot = document.getElementById('CompNon').value;
  const description = document.getElementById('Des').value;
  if (rational == "" || ppacNumber == "" || proposingUnit == "" || productName == "" || typeOfNote == "" || detailsOfChanges == "default" 
|| rationalOfModification == "" || complexityOrNot == "" || description == "" ) {
	
alert("Please complete all the fields!");
} else {
$scope.onFileSelected();

  // Call the generateUniqueID function and pass a callback function to use the unique ID
  generateUniqueID(function(reqId) {
    console.log(reqId); 
    const payload = { 
      reqID: reqId,
	  reqType: selectedRadioName,
	RationalNew: rational,
    PPACNum: ppacNumber,
    PUName: proposingUnit,
    ProName: productName,
    TypeOfNote: typeOfNote,
    DetailsOfChanges: detailsOfChanges,
    RationalMod: rationalOfModification,
    ComplexityOrNot: complexityOrNot,
    Desc: description

    };
  


const endpointUrl = "_api/web/lists/getByTitle('PPAC Request')/items";
// Send the request to create the list item
Hyper.post(endpointUrl, payload)
  .success(function(result) {
	  
    alert("Request Submitted - Request ID: "+ reqId );
  })
  .error(function(error) {
    console.log("Error creating item: ", error);
  });
  });
}
}
});

