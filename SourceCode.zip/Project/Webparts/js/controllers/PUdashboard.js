PPAC.controller("puDashBoard", function($scope, $rootScope, $sce, $filter, $location, $routeParams, $timeout, Hyper, SITE_SETTINGS) {
  console.log("PUDashBoard");

  $scope.loginuser = SITE_SETTINGS.userInfo.name;
  $scope.Raised = [];
  $scope.BuApproval = [];
  $scope.Closed = [];
  $scope.listData = [];

  $scope.data = function() {
    Hyper.get("_api/web/lists/getByTitle('PPAC Request')/items")
      .success(function(response) {
        for (var i = 0; i < response.d.results.length; i++) {
          var item = response.d.results[i];

          if (item.status === "Raised" || item.status === "Awaiting BUH Approval") {
            $scope.Raised.push(item.status);
          }
          if (item.status === "BUHeadApproved") {
            $scope.BuApproval.push(item.status);
          }
          if (item.status === "Approved") {
            $scope.Closed.push(item.status);
          }

          var id = item.ID;
          var reqID = item.PPACNo;
          var name = item.proposer;
          var reqType = item.reqType;
          var modified = item.Modified;
          var status = item.status;
          console.log(reqID + name + reqType + modified + status);

          // Add the item to the listData array
          $scope.listData.push({
            'ID column': id,
            'PPACnumber column': reqID,
            'Proposername column': name,
            'request type column': reqType,
            'Number of days from created column': modified,
            'status column': status
          });
        }

        $scope.RaisedLength = $scope.Raised.length;
        $scope.BuApprovalLength = $scope.BuApproval.length;
        $scope.ClosedLength = $scope.Closed.length;
        $scope.TotalQueries = response.d.results.length;
      })

      .error(function(er) {
        console.log("error1:", er);
        return null;
      });
  };

  $scope.data();
});






//   Hyper.get("_api/web/lists/getByTitle('PPAC Request')/items")
//         .success(function (response) {
// var count = 0;
// var buCount =0;
// var ruCount =0;
// var closedCount =0;
// for (var i = 0; i < response.d.results.length; i++) {
//     var item = response.d.results[i];
//     if($scope.loginuser === item.proposer){
//       count++;
//     }
//     if("Raised" === item.status || "Awaiting BUH Approval"=== item.status ){
//       buCount++;
//     }
//     if("BUHeadApproved" === item.status){
//       ruCount++;
//     }
//     if("Approved" === item.status){
//       closedCount++;
//     }

// }
// $scope.TotalQueries = count;
// console.log("count" + $scope.TotalQueries);

// $scope.TotalBUHQueries = buCount;
// console.log("count" + $scope.TotalBUHQueries);

// $scope.TotalRUQueries = ruCount;
// console.log("count" + $scope.TotalRUQueries);

// $scope.TotalclosedQueries =closedCount;
// console.log("count" + $scope.TotalclosedQueries);

// $scope.listData = []; // Array to store the list items

// for (var i = 0; i < response.d.results.length; i++) {
//    var item = response.d.results[i];
//    if ($scope.loginuser === item.proposer) {
//       var id =item.ID;
//       var reqID = item.PPACNo;
//       var name = item.proposer;
//       var reqType = item.reqType;
//       var modified = item.Modified;
//       var status = item.status;
//       console.log(reqID + name + reqType + modified + status);

//       // Add the item to the listData array
//       $scope.listData.push({
//           'ID column': id,
//          'PPACnumber column': reqID,
//          'Proposername column': name,
//          'request type column': reqType,
//          'Modified': modified,
//          'status column': status
//       });
//    }
// }
// $scope.gen();
//         })
//         .error(function (er) {
//                 console.log("error1:", er);
//                 return null;
//             })

// $scope.gen = function() {
//   const container = $("#containers");

//   function generateCard(item) {
//     const modifiedDate = new Date(item.Modified); // Assuming "Modified" is the column name
//     var agingDays = "-";
//     if (item['status column'] !== "Awaiting BUH Approval" && item['status column'] !== "Raised") {
//       agingDays = Math.floor((new Date() - modifiedDate) / (1000 * 60 * 60 * 24));
//     }

//     var cardDiv = $('<div class="card-main-div">' +
//       '<div class="row d-flex justify-content-between p-2 col-md-12 m-0">' +
//       '<div class="col-md-9 card_cntr">' +
//       '<div class="row">' +
//       '<div class="col-md-3 value-ppac req-id">' +
//       '<h5>' + item['PPACnumber column'] + '</h5>' +
//       '</div>' +
//       '<div class="value-ppac col-md-3">' +
//       '<label for="" class="label-ppac">AD ID of Proposer</label>' +
//       '<input type="text" readonly class="form-control-plaintext" id="staticEmail" value="' + item['Proposername column'] + '">' +
//       '</div>' +
//       '<div class="value-ppac col-md-3">' +
//       '<label for="" class="label-ppac">Ageing Days</label>' +
//       '<input type="text" readonly class="form-control-plaintext" id="staticEmail" value="' + agingDays + '">' +
//       '</div>' +
//       '</div>' +
//       '</div>' +
//       '<div class="col-md-3 row-p_fix">' +
//       '<div class="status">' +
//       '<button type="button" class="status-update" data-id="' +  item['ID column']+ '">' + item['status column'] + '</button>' +
//       '<span class="badge-circle"><p>4</p></span>' +
//       '</div>' +
//       '</div>' +
//       '</div>' +
//       '</div>');

//     container.append(cardDiv);

//    $('.status-update').click(function(e) {
//   var id = $(this).data('id');
//   console.log(id);
//   $location.url("'/request/' + id");
//   console.log($location.url("/request/" + id));
  
// });
//   }

//   for (var i = 0; i < $scope.listData.length; i++) {
//     generateCard($scope.listData[i]);
//   }
// }

// });