PPAC.controller("switchRoleCtrl", function($scope, $rootScope, $filter, $timeout, $location, Hyper, SITE_SETTINGS) {
	console.log('switchRoleCtrl');
	$scope.roles = SITE_SETTINGS.userInfo.roles;
	console.log("$scope.roles", SITE_SETTINGS.userInfo.roles,SITE_SETTINGS.userInfo.loginRole);
	
	$scope.setLoginRole = function(role, dash) {
		SITE_SETTINGS.userInfo.loginRole= role;
		var temp = JSON.parse(sessionStorage.getItem("SITE_SETTINGS"));
		temp.userInfo.loginRole = role;
		sessionStorage.setItem("SITE_SETTINGS", JSON.stringify(SITE_SETTINGS));
		
		if (role == 'PU') {
			$location.path("/CreateRequestPU");
		} else if(role == 'ORM') {
			$location.path("/ORMConfig");
		}
	}
	
	if ($scope.roles.length == 1) {
		$scope.setLoginRole($scope.roles[0]);
	}

});