PPAC.controller("buhDashBoard", function($scope, $rootScope, $sce, $filter, $location, $compile, $routeParams, $timeout, Hyper, SITE_SETTINGS) {
  console.log("buhDashBoard");
  $scope.loginuser = SITE_SETTINGS.userInfo.name;


$scope.loginuser = SITE_SETTINGS.userInfo.name;
$scope.Raised = [];
$scope.BuApproval =[];
$scope.Closed = [];
$scope.listData = [];

$scope.data= function(){
  Hyper.get( "_api/web/lists/getByTitle('PPAC Request')/items?$filter=proposer eq '" + $scope.loginuser + "'")
   .success(function (response) {
     for (var i = 0; i < response.d.results.length; i++){
       var item = response.d.results[i];
       
        if("Raised" === item.status || "Awaiting BUH Approval"=== item.status ){
          $scope.Raised.push(item.status);
        }
        if("BUHeadApproved" === item.status){
           $scope.BuApproval.push(item.status);
        }
        if("Approved" === item.status){
          $scope.Closed.push(item.status);
        }

        var id = item.ID;
          var reqID = item.PPACNo;
          var name = item.proposer;
          var reqType = item.reqType;
          var modified = item.Modified;
          var status = item.status;
          console.log(reqID + name + reqType + modified + status);

          // Add the item to the listData array
          $scope.listData.push({
            'ID column': id,
            'PPACnumber column': reqID,
            'Proposername column': name,
            'request type column': reqType,
            'Number of days from created column': modified,
            'status column': status
          });
     }
     $scope.RaisedLength = $scope.Raised.length;
$scope.BuApprovalLength = $scope.BuApproval.length;
$scope.ClosedLength = $scope.Closed.length;
$scope.TotalQueries = response.d.results.length;
   })
   
}
$scope.data();


//   Hyper.get("_api/web/lists/getByTitle('PPAC Request')/items")
//     .success(function(response) {
//       var count = 0;
//       var buCount = 0;
//       var ruCount = 0;
//       var closedCount = 0;
//       for (var i = 0; i < response.d.results.length; i++) {
//         var item = response.d.results[i];
//         if ($scope.loginuser === item.proposer) {
//           count++;
//         }
//         if ("Raised" === item.status|| "Awaiting BUH Approval"=== item.status) {
//           buCount++;
//         }
//         if ("BUHeadApproved" === item.status) {
//           ruCount++;
//         }
//         if ("Approved" === item.status) {
//           closedCount++;
//         }
//       }
//       $scope.TotalQueries = count;
//       console.log("count" + $scope.TotalQueries);

//       $scope.TotalBUHQueries = buCount;
//       console.log("count" + $scope.TotalBUHQueries);

//       $scope.TotalRUQueries = ruCount;
//       console.log("count" + $scope.TotalRUQueries);

//       $scope.TotalclosedQueries = closedCount;
//       console.log("count" + $scope.TotalclosedQueries);

//       $scope.listData = []; // Array to store the list items

//       for (var i = 0; i < response.d.results.length; i++) {
//         var item = response.d.results[i];
//         console.log(item.status);
//         if ("Raised" === item.status || "Awaiting BUH Approval" === item.status) {
//           var reqID = item.PPACNo;
//           var name = item.proposer;
//           var reqType = item.reqType;
//           var modified = item.Modified;
//           var status = item.status;
//           console.log(reqID + name + reqType + modified + status);

//           // Add the item to the listData array
//           $scope.listData.push({
//             'PPACnumber column': reqID,
//             'Proposername column': name,
//             'request type column': reqType,
//             'Modified': modified,
//             'status column': status
//           });
//         }
//       }

//       $scope.gen();
//     })
//     .error(function(er) {
//       console.log("error1:", er);
//       return null;
//     });

// $scope.gen = function() {
//   var container = $('#containers');
//   container.empty();

//   for (var i = 0; i < $scope.listData.length; i++) {
//     var item = $scope.listData[i];
//     var modifiedDate = new Date(item.Modified);
//     var agingDays = "-";

//     var cardDiv = $('<div class="card-main-div">' +
//       '<div class="row d-flex justify-content-between p-2 col-md-12 m-0">' +
//       '<div class="col-md-9 card_cntr">' +
//       '<div class="row">' +
//       '<div class="col-md-3 value-ppac req-id">' +
//       '<h5>' + item['PPACnumber column'] + '</h5>' +
//       '</div>' +
//       '<div class="value-ppac col-md-3">' +
//       '<label for="" class="label-ppac">AD ID of Proposer</label>' +
//       '<input type="text" readonly class="form-control-plaintext" id="staticEmail" value="' + item['Proposername column'] + '">' +
//       '</div>' +
//       '<div class="value-ppac col-md-3">' +
//       '<label for="" class="label-ppac">Request Type</label>' +
//       '<input type="text" readonly class="form-control-plaintext" id="staticEmail" value="' + item['request type column'] + '">' +
//       '</div>' +
//       '<div class="value-ppac col-md-3">' +
//       '<label for="" class="label-ppac">Ageing Days</label>' +
//       '<input type="text" readonly class="form-control-plaintext" id="staticEmail" value="' + agingDays + '">' +
//       '</div>' +
//       '</div>' +
//       '</div>' +
//       '<div class="col-md-3 row-p_fix">' +
//       '<div class="status">' +
//       '<button type="button" class="status-update">Approve</button>' +
//       '<button type="button" class="reject-update">Reject</button>' +
//       '<span class="badge-circle"><p>4</p></span>' +
//       '</div>' +
//       '</div>' +
//       '</div>' +
//       '</div>');

//     container.append(cardDiv);
//   }

//   $compile(container)($scope);

//   container.on('click', '.status-update', function(e) {
//     $scope.card = $(this).closest('.card-main-div');
//      $scope.reqID = $scope.card.find('.req-id h5').text();
//     Hyper.get("/_api/web/lists/getbytitle('PPAC Request')/items")
//    .success(function(response) {
//       alert("j");
//         for (var i = 0; i < response.d.results.length; i++) {
//           var item = response.d.results[i];
//           if(item.PPACNo === $scope.reqID){
//              $scope.id = item.ID;
//           }
//         }
//         console.log($scope.id +"l");
//         $scope.update();
//     })
//     $scope.update =function(){
    
    
//     console.log('Approving item:', $scope.reqID);
//      $scope.status="In Review Unit"
//     url="/_api/web/lists/getbytitle('PPAC Request')/items";
//     var payload = {
//     status: $scope.status
//   };
//   payload["__metadata"] ={
//      "type": "SP.Data.PPAC_x0020_RequestListItem"
//     };
//      Hyper.merge(url+ "(" + $scope.id +")",payload )
//      .success(function(res){
//        console.log(res);
//        alert("BUH Approved");
//      }).error(function(er){
//         console.log(er);
//        });
//         e.preventDefault();
//     }
//   });

//   container.on('click', '.reject-update', function(e) {
    
//     var card = $(this).closest('.card-main-div');
//     var reqID = card.find('.req-id h5').text();
//  Hyper.get("/_api/web/lists/getbytitle('PPAC Request')/items")
//    .success(function(response) {
//         for (var i = 0; i < response.d.results.length; i++) {
//           var item = response.d.results[i];
//           if(item.PPACNo === reqID){
//              $scope.id = item.ID;
//           }
//         }
//         console.log($scope.id);
//     })

//     console.log('Rejecting item:', reqID);
//      $scope.status="BUH Declined"
//     url="/_api/web/lists/getbytitle('PPAC Request')/items";
//     var payload = {
//     status: $scope.status
//   };
//   payload["__metadata"] ={
//      "type": "SP.Data.PPAC_x0020_RequestListItem"
//     };
//      Hyper.merge(url+ "(" + $scope.id +")",payload )
//      .success(function(res){
//        console.log(res);
//        alert("BUH Declined");
//      }).error(function(er){
//         console.log(er);
//        });
//         e.preventDefault();
//   });
// };

});