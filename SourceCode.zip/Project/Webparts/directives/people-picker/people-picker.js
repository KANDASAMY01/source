PPAC.directive("peoplePicker", function(Hyper, SITE_SETTINGS, $timeout) {
	return  {
		restrict:'E',
		template:'<div class="custom-people-picker"></div>',
		replace:true,
		scope: {
			selected:"=",
			allowMultiple:"=",
			customClass:"="
		},
		link:function(scope, elem , attributes) {
			
			
			var eleId = "peoplepicker_"+scope.$id+"_"+moment().unix();
			var isMulti = scope.allowMultiple || false;
			elem[0].id = eleId;
			
			console.log("------peoplePicker--------");
			console.log("eleId", eleId);
			console.log("selected", scope.selected);
			console.log("allowMultiple", scope.allowMultiple);
			console.log("customClass", scope.customClass);
			console.log("--------------------------------");
			if (scope.customClass) {			
				elem[0].classList.add(scope.customClass)
			}
			// People Picker Start
			scope.initPeoplePicker = function() {
		    	var oldhtml = '';
		    	$('div [id^="'+eleId +'"]').html(oldhtml);
		
		        $timeout(function(){
						$('#'+eleId).spPeoplePicker(function(res) {
						    scope.OnUserResolvedClientScript(res, isMulti, eleId);
						},isMulti);
						$( "#"+eleId+"_TopSpan" ).addClass( "form-control" ); 
		                $timeout(function(){ 
			               	$( "#"+eleId+"_TopSpan_EditorInput" ).addClass("people-picker");
			               	
							if (isMulti) { 
				               	if (scope.selected.length > 0) {
				               		for (var i=0;i<scope.selected.length;i++) {
										scope.SetAndResolvePeoplePicker(scope.selected[i]);
				               		}
								} 
							} else if (scope.selected) {
								scope.SetAndResolvePeoplePicker(scope.selected);
							}         
			            },100);	            
		        }, 500);
		    }
		    
		    scope.SetAndResolvePeoplePicker = function(userAccountName) {
		  		//console.log(userAccountName, divID);
		  		var divID = eleId+'_TopSpan';
				SP.SOD.loadMultiple(['sp.core.js', 'sp.runtime.js', 'sp.js', 'autofill.js', 'clientpeoplepicker.js', 'clientforms.js', 'clienttemplates.js'], function() {
				  	var titleTxt = 'Type Name/Email';
				  	var peoplePickerDiv = $("[id$="+divID+"][title='"+titleTxt +"']");
					var peoplePickerEditor = peoplePickerDiv.find("[title='"+titleTxt +"']");		
					var spPeoplePicker = SPClientPeoplePicker.SPClientPeoplePickerDict[divID];
					
					if (peoplePickerEditor) {
						peoplePickerEditor.val(userAccountName);
					}
					if (spPeoplePicker) {
						spPeoplePicker.AddUnresolvedUserFromEditor(true);
					}
				});
			}
			
			scope.OnUserResolvedClientScript = function(userKey) {
		        try {
		            var temp = userKey;
		            scope.selected= isMulti ? [] : null;
		            if (userKey.length > 0) {
		            	var userIds = [];
		            	angular.forEach(userKey, function(user, index) {
		            		// console.log(user, index);
		            		var usr = user.Key.split('|membership|')
		            		var email =  usr[1]|| usr[0];
		            		if (userIds.indexOf(email)==-1) {
		            			userIds.push(email);
			                	scope.updateListData(email);
		            		}else {
		            			$('a[title="Remove person or group '+user.DisplayText+'"]')[0].click();
		            		}  
		            	});
		               
		            }
		        } catch (e) {
		            //console.log(e);
		        }
		    }
		
		    scope.updateListData = function(user) {
		        var url = "_vti_bin/listdata.svc/UserInformationList?$select=Id,Name,UserName&$filter=UserName eq '" + user + "'";
		        try {
		            Hyper.get(url)
		                .then(function success(resp) {
		                    if (resp.data.d.results.length >= 1) {
		                    	if (isMulti) {
		                    		scope.selected.push(resp.data.d.results[0]);
		                    	} else {
		                    		scope.selected = resp.data.d.results[0];
		                    	}
		                    } else {
		                        scope.ensureUser(user);
		                    }
		
		                }, function error(resp) {
		                    //console.log("Error - ", resp)
		                });
		        } catch (e) {
		           // console.log('exception', e);
		        }
		    }
		
		
		    scope.ensureUser = function(user) {
		        if (user != null && user != undefined && user.trim().length > 0) {
		            var url = "_api/web/ensureuser";
		            var data = "{ 'logonName':'i:0#.f|membership|" + user + "'}"
		            Hyper.post(url, data)
		            .then(function success(resp) {
		                scope.updateListData(user);
		            },
		            function error(resp) {
		               	alert('The selected person cannot be added.');
		            });
		        }
		    }
		    
		    scope.initPeoplePicker();
			
		}
		
	}
})