PPAC.service("Hyper", function ($http, $q, SITE_SETTINGS) {

	this.get = function (url, headers, isExternal) {

		var _headers = { "Accept": "application/json;odata=verbose" };
		var _getUrl = '';
		if (headers != undefined) {
			for (var x in headers) {
				_headers[x] = headers[x];
			}
		}
		if (isExternal) {
			_getUrl = url
		} else {
			_getUrl = SITE_SETTINGS.site_url + url
		}
		return $http({
			method: "GET",
			url: _getUrl,
			headers: _headers
		})

	}

	this.merge = function (url, data, headers, isExternal) {
		var _headers = {
			"Accept": "application/json;odata=verbose",
			"Content-Type": "application/json;odata=verbose",
			"X-RequestDigest": document.getElementById("__REQUESTDIGEST").value,
			"IF-MATCH": "*",
			"X-Http-Method": "MERGE"
		};
		var _getUrl = '';
		if (headers != undefined) {
			for (var x in headers) {
				_headers[x] = headers[x];
			}
		}
		if (isExternal) {
			_getUrl = url
		} else {
			_getUrl = SITE_SETTINGS.site_url + url
		}

		return $http({
			method: "POST",
			url: _getUrl,
			headers: _headers,
			data: data
		})
	}

	this.put = function (url, data, headers, isExternal) {
		var _headers = {
			"Accept": "application/json;odata=verbose",
			"Content-Type": "application/json;odata=verbose"
		};
		var _getUrl = '';
		if (headers != undefined) {
			for (var x in headers) {
				_headers[x] = headers[x];
			}
		}
		if (isExternal) {
			_getUrl = url
		} else {
			_getUrl = SITE_SETTINGS.site_url + url
		}

		return $http({
			method: "PUT",
			url: _getUrl,
			headers: _headers,
			data: JSON.stringify(data)
		})
	}

	this.post = function (url, data, headers, isExternal) {
		var _headers = {
			"Accept": "application/json",
			"Content-Type": "application/json",
		};
		var _getUrl = '';
		if (headers != undefined) {
			for (var x in headers) {
				_headers[x] = headers[x];
			}
		}
		else {
			if (!isExternal) {
				_headers["X-RequestDigest"] = document.getElementById("__REQUESTDIGEST").value;
				_headers["IF-MATCH"] = "*";
				_headers["X-Http-Method"] = "POST";
			}
		}
		if (isExternal) {
			_getUrl = url
		} else {
			_getUrl = SITE_SETTINGS.site_url + url
		}

		return $http({
			method: "POST",
			url: _getUrl,
			headers: _headers,
			data: JSON.stringify(data),
		})
	}

	this.listItemDelete = function (url, isExternal, headers) {
		var _headers = {
			"Accept": "application/json;odata=verbose",
			"Content-Type": "application/json;odata=verbose",
			"X-RequestDigest": document.getElementById("__REQUESTDIGEST").value,
			"IF-MATCH": "*",
			"X-Http-Method": "DELETE"
		};
		var _getUrl = '';
		if (headers != undefined) {
			for (var x in headers) {
				_headers[x] = headers[x];
			}
		}
		if (isExternal) {
			_getUrl = url
		} else {
			_getUrl = SITE_SETTINGS.site_url + url
		}

		return $http({
			method: "POST",
			url: _getUrl,
			headers: _headers,
		})
	}




	this.uploadFile = function (elementId, docLibrary, fileName) {
		var deferred = $q.defer();
		var element = document.getElementById(elementId);

		var file = element.files[0];
		if (file == undefined) {
			return null;
		} else if (file == null) {
			return null;
		}
		var parts = element.value.split('\\');
		var fName = parts[parts.length - 1];
		if (fileName == undefined) {
			fileName = fName;
		} else {
			var ext = fName.split('.').pop();
			fileName = fileName + '.' + ext;
		}
		console.log("fileName-", fileName);
		var reader = new FileReader();
		reader.readAsArrayBuffer(file);
		reader.onloadend = function (e) {
			var arrBuff = e.target.result;
			var fileCollectionEndpoint = SITE_SETTINGS.site_url + "_api/Web/Lists/getByTitle('" + docLibrary + "')/RootFolder/Files/Add(url='" + fileName + "', overwrite=true)?$expand=ListItemAllFields";
			var request = $http({
				url: fileCollectionEndpoint,
				method: "POST",
				processData: false,
				data: arrBuff,
				transformRequest: angular.identity,
				headers: {
					"accept": "application/json;odata=verbose",
					"X-RequestDigest": document.getElementById("__REQUESTDIGEST").value,
					"Content-Type": undefined,
					"Content-Length": arrBuff.byteLength
				}
			}).success(function (data) {
				deferred.resolve(data.d);
			}).error(function () {
				deferred.reject("Error");
			})

		}
		return deferred.promise;
	}

	this.uploadFileInstance = function (docLibrary, fileName, file) {
		var deferred = $q.defer();

		if (file == undefined) {
			return null;
		} else if (file == null) {
			return null;
		}
		var fName = file.name;
		if (fileName == undefined) {
			fileName = fName;
		} else {
			var ext = fName.split('.').pop();
			fileName = fileName + '.' + ext;
		}
		console.log("fileName-", fileName);
		var reader = new FileReader();
		reader.readAsArrayBuffer(file);
		reader.onloadend = function (e) {
			var arrBuff = e.target.result;
			var fileCollectionEndpoint = SITE_SETTINGS.site_url + "_api/Web/Lists/getByTitle('" + docLibrary + "')/RootFolder/Files/Add(url='" + fileName + "', overwrite=true)?$expand=ListItemAllFields";
			var request = $http({
				url: fileCollectionEndpoint,
				method: "POST",
				processData: false,
				data: arrBuff,
				transformRequest: angular.identity,
				headers: {
					"accept": "application/json;odata=verbose",
					"X-RequestDigest": document.getElementById("__REQUESTDIGEST").value,
					"Content-Type": undefined,
					"Content-Length": arrBuff.byteLength
				}
			}).success(function (data) {
				deferred.resolve(data.d);
			}).error(function () {
				deferred.reject("Error");
			})

		}
		return deferred.promise;
	}


	this.moveFile = function (url) {
		var _headers = {
			"Accept": "application/json;odata=verbose",
			"Content-Type": "application/json;odata=verbose",
			"X-RequestDigest": document.getElementById("__REQUESTDIGEST").value,
			"IF-MATCH": "*",
			"X-Http-Method": "MERGE"
		};

		return $http({
			method: "POST",
			url: SITE_SETTINGS.site_url + url,
			headers: _headers,
		})
	}

	this.siteDelete = function (url, data, headers) {
		var _headers = {
			"Accept": "application/json;odata=verbose",
			"Content-Type": "application/json;odata=verbose",
			"X-RequestDigest": document.getElementById("__REQUESTDIGEST").value,
			"IF-MATCH": "*",
			"X-Http-Method": "POST"
		};

		if (headers != undefined) {
			for (var x in headers) {
				_headers[x] = headers[x];
			}
		}

		return $http({
			method: "DELETE",
			url: SITE_SETTINGS.site_url + url,
			headers: _headers,
			data: data
		})
	}
});