PPAC.controller("createRequestCtrl", function($scope, $rootScope, $filter, $location,$routeParams,$timeout, Hyper, SITE_SETTINGS) {
	console.log("createRequestCtrl");
  console.log(Hyper);
  if ($routeParams["ID"]){
    $scope.propID =parseInt($routeParams["ID"]);
    alert("hi");
  }
	$scope.formData={
		reqType:"New To Bank",
		rational:"",
		PPACNO:"",
		propUnit:"",
		procName:"",
		typeNote:"",
		detailChng:"",
		ratModif:"",
		initDt:"",
		lastDt:"",
		comp:"",
		nxtRDt:"",
		brfDesc:""			
	}
$scope.filename="";
$scope.status="Draft";
$scope.loginuser = SITE_SETTINGS.userInfo.name;

$scope.propUnitList =[];
$scope.PropUnitList=function(lkpFieldName){
  Hyper.get("_api/web/lists/getByTitle('	Proposing Unit')/items")
  .success(function(response){
    var propList =[];
    for(var i=0;i<response.d.results.length; i++){
      var item=response.d.results[i];
      propList.push(item.PropUnit);
    }
    $scope[lkpFieldName]= propList;
  })
  .error(function(er){
    console.log("error",er)
  })
}
$scope.PropUnitList("propUnitList");

//Fields On change validation
$scope.procNameVaidation = function () { 
  
    if($scope.formData.procName.length > 0){
			$scope.procNameStdAlertMessage="";
		} 
    if($scope.formData.procName.length === 0){
			$scope.procNameStdAlertMessage="Please Enter Product / Process Name"
		}
    
}
$scope.rationalVaidation = function () {
  
    if($scope.formData.rational.length > 0){
			$scope.rationalStdAlertMessage=""
		} 
    if($scope.formData.rational.length === 0){
			$scope.rationalStdAlertMessage="Please Enter Rational for New To Bank"
		}
} 
$scope.propUnitVaidation = function () {  
    if($scope.formData.propUnit.length>0){
			$scope.propUnitStdAlertMessage=""
		}  
    if($scope.formData.propUnit.length === 0){
			$scope.propUnitStdAlertMessage="Please Enter Proposing Unit Name"
		}
}

$scope.detailChngVaidation = function () {  
    if($scope.formData.detailChng.length > 0){
			$scope.detailChngStdAlertMessage=""
		}
    if($scope.formData.detailChng.length === 0){
			$scope.detailChngStdAlertMessage="Please Enter Change of Details"
		}

}
$scope.ratModifVaidation = function () { 
    if($scope.formData.ratModif.length>0){
			$scope.ratModifStdAlertMessage=""
		} 
    if($scope.formData.ratModif.length === 0){
			$scope.ratModifStdAlertMessage="Please Enter Rational Modification"
		}
      
}
$scope.compVaidation = function () { 
    if($scope.formData.comp.length>0){
			$scope.compStdAlertMessage=""
		} 
    if($scope.formData.comp.length === 0){
			$scope.compStdAlertMessage="Please Select Complexity or Not"
		}
}
$scope.brfDescVaidation = function () { 
    if($scope.formData.brfDesc.length>0){
			$scope.brfDescStdAlertMessage=""
		}
    if($scope.formData.brfDesc.length === 0){
			$scope.brfDescStdAlertMessage="Please Enter Brief Description"
		}
}
$scope.lrdVaidation = function () { 
    if($scope.formData.lastDt.length > 0){
			$scope.lrdStdAlertMessage=""
		} 
    if($scope.formData.lastDt.length === 0){
			$scope.lrdStdAlertMessage="Please select the Last Review Date"
		} 
}
$scope.initDtVaidation = function () { 
    if($scope.formData.initDt.length > 0){
			$scope.initDtStdAlertMessage=""
		} 
    if($scope.formData.initDt.length === 0){
			$scope.initDtStdAlertMessage="Please select the Initial Review Date"
		} 
}
$scope.nxtRDtVaidation = function () { 
    if($scope.formData.nxtRDt.length > 0){
			$scope.nxtRDtStdAlertMessage=""
		} 
    if($scope.formData.nxtRDt.length === 0){
			$scope.nxtRDtStdAlertMessage="Please select the Next Review Date"
		} 
}	
    	
//End of fields on change validation.
    
$scope.LoadAnswers=function(){
  if($scope.propID>0){
    _url="_api/web/lists/getByTitle('PPAC Request')/items?$filter=ID eq"+scope.propID+"&$select=reqType,PPACNo,rational,pu,prod,changes,modi,deac,initDt,lastDt,nxtRDT";
    Hyper.get(_url)
    .success(function(res){
      if(res.d.result && res.d.result.length>0){
        var item = res.d.result[0];
        $scope.formData.reqType =item.reqType;
        $scope.uniqueId=item.PPACNo;
        $scope.formData.rational=item.rational;
        $scope.formData.propUnit=item.pu;
        $scope.formData.procName=item.prod;
        $scope.formData.detailChng=item.changes;
        $scope.formData.ratModif=item.modi;
        $scope.formData.comp=item.comp;
        $scope.formData.brfDesc=item.desc;
        $scope.formData.initDt=item.initDt;
        $scope.formData.lastDt=item.lastDt;
        $scope.formData.nxtRDt=item.nxtDt;
              }

    })
    .error(function(er){
      console.log("error:",er);
    })
  }
}
$scope.LoadAnswers();


 //search People
 document.getElementById('search-box').addEventListener('input', function() {
  var searchText = this.value;
  if (searchText) {
    Hyper.get("/_api/search/query?querytext='*" + searchText + "*'&selectproperties='PreferredName,AccountName,Department'&sourceid='B09A7990-05EA-4AF9-81EF-EDFAB16C4E31'")
      .success(function(response) {
        var data = JSON.parse(response);
        var results = data.d.query.PrimaryQueryResult.RelevantResults.Table.Rows.results;
        if (results.length > 0) {
          var previewContainer = document.getElementById('preview-container');
          previewContainer.innerHTML = '';
          for (var i = 0; i < results.length; i++) {
            var accountName = results[i].Cells.results[1].Value;
            var displayName = results[i].Cells.results[3].Value;
            var department = results[i].Cells.results[5].Value;
            var previewDiv = document.createElement('div');
            previewDiv.className = 'main-file d-flex ms-2';
            var subFileDiv = document.createElement('div');
            subFileDiv.className = 'sub-file';
            var userIcon = document.createElement('i');
            userIcon.className = 'bi bi-person';
            subFileDiv.appendChild(userIcon);
            previewDiv.appendChild(subFileDiv);
            var previewParagraph = document.createElement('p');
            previewParagraph.className = 'p-2';
            previewParagraph.textContent = displayName;
            previewDiv.appendChild(previewParagraph);
            var xIcon = document.createElement('i');
            xIcon.className = 'bi bi-x';
            xIcon.addEventListener('click', function() {
              previewDiv.remove();
              document.getElementById('search-box').value = '';
            });
            previewDiv.appendChild(xIcon);
            previewContainer.appendChild(previewDiv);
          }
        }
      });
  }
});

//Unique ID
	$scope.uniqueId = null;
generateUniqueID(function(uniqueID){
    $scope.uniqueId = uniqueID; 
		console.log($scope.uniqueId);
});
function generateUniqueID(callback){
    Hyper.get("_api/web/lists/getByTitle('PPAC Request')/items")
    .success(function(response){
			
        var highestNumber = 100;
        angular.forEach(response.d.results, function (item) {
            var columnName = "PPACNo"; 
            var id = item[columnName];
            if (id) {
                var number = parseInt(id.match(/\d+$/)[0]);
                if (number > highestNumber) {
                    highestNumber = number;
                    console.log(highestNumber);
                }
            }
        });
        var uniqueID = "PPAC" + (highestNumber + 1).toString();
        console.log(uniqueID +"l");
        callback(uniqueID);
    });
}


//Search


const searchNotesInput = document.querySelector('#searchNotes');
const resultsDiv = document.querySelector('#search-results');

searchNotesInput.addEventListener('keyup', function(event) {
  const searchTerm = event.target.value;
  if (searchTerm.length >= 3) {
    searchFiles(searchTerm);
  } else {
    resultsDiv.innerHTML = '';
  }
});

function searchFiles(searchTerm) {
  const url = "/_api/web/lists/getByTitle('Notes')/items?$select=EncodedAbsUrl,FileLeafRef&$filter=substringof('" + searchTerm + "',FileLeafRef)";
  Hyper.get(url)
    .success(function (data) {
      resultsDiv.innerHTML = '';
      if (data.d.results.length === 0) {
        resultsDiv.textContent = 'No files found.';
        return;
      }
      data.d.results.forEach(function(result) {
        const mainFileDiv = document.createElement('div');
        mainFileDiv.className = 'main-file d-flex ms-2';
        const subFileDiv = document.createElement('div');
        subFileDiv.className = 'sub-file';
        const fileIcon = document.createElement('i');
        fileIcon.className = 'bi bi-file-earmark';
        fileIcon.addEventListener('click', function() {
          // Trigger the download action
          const a = document.createElement('a');
          a.href = result.EncodedAbsUrl;
          a.download = result.FileLeafRef;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        });
        subFileDiv.appendChild(fileIcon);
        mainFileDiv.appendChild(subFileDiv);
        const fileNameParagraph = document.createElement('p');
        fileNameParagraph.className = 'p-2';
        fileNameParagraph.textContent = result.FileLeafRef;
        mainFileDiv.appendChild(fileNameParagraph);
        resultsDiv.appendChild(mainFileDiv);
      });
    })
    .error(function(error) {
      console.log("search error: ", error);
    });
}



//File Upload and Preview

$scope.id = 1;
$scope.attach = []; 
$scope.onFileSelected = function() {
  var element = document.getElementById('file-upload');
  var files = element.files;

  for (var i = 0; i < files.length; i++) {
    var file = files[i];
    var fileName = file.name;
    $scope.filename =fileName;
    var extension = fileName.split('.').pop();
    var nameWithoutExtension = fileName.substring(0, fileName.length - extension.length - 1);

    Hyper.uploadFileInstance('Notes', nameWithoutExtension, file)
      .then(function(response) {
        $scope.docId = response.ListItemAllFields.ID;
        $scope.reqType1 = $scope.formData.reqType;
        $scope.PPACNo1 = $scope.uniqueId;
        $scope.nameWithoutExtension =nameWithoutExtension;
        alert('File(s) uploaded successfully');
        console.log($scope.docId,+"ee");
        $scope.update();
        
      })
      .catch(function(error) {
        console.error('Error uploading file:', error);
        alert('An error occurred while uploading the file(s). Please try again later.');
      });
  }
};
//Preview
const fileUploadInput = document.querySelector('#file-upload');
const mainFileContainer = document.querySelector('#main-file-container');
let isUploading = false;

fileUploadInput.addEventListener('change', function() {
  // If already uploading, return
  if (isUploading) {
    return;
  }
  // Set isUploading to true
  isUploading = true;

  const files = this.files;
  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const mainFileDiv = document.createElement('div');
    mainFileDiv.className = 'main-file d-flex ms-2';
    const subFileDiv = document.createElement('div');
    subFileDiv.className = 'sub-file';
    const fileIcon = document.createElement('i');
    fileIcon.className = 'bi bi-file-earmark';
    fileIcon.addEventListener('click', function() {
      // Trigger the download action
      const url = URL.createObjectURL(file);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    });
    subFileDiv.appendChild(fileIcon);
    mainFileDiv.appendChild(subFileDiv);
    const fileNameParagraph = document.createElement('p');
    fileNameParagraph.className = 'p-2';
    fileNameParagraph.textContent = file.name;
    mainFileDiv.appendChild(fileNameParagraph);
    const xIcon = document.createElement('i');
    xIcon.className = 'bi bi-x';
    xIcon.addEventListener('click', function() {
      mainFileDiv.remove();
      fileUploadInput.value = null;
    });
    mainFileDiv.appendChild(xIcon);
    mainFileContainer.appendChild(mainFileDiv);
  }

  
  isUploading = false;
});


	$scope.onChangeType = function (item) {
      
      $scope.formData = {
    reqType:$scope.formData.reqType,
    rational:"",
    PPACNO:"",
    propUnit:"",
    procName:"",
    typeNote:"",
    detailChng:"",
    ratModif:"",
    initDt:"",
    lastDt:"",
    comp:"",
    nxtRDt:"",
    brfDesc:""      
  };
      console.log($scope.formData.reqType);

    };
$scope.save=function(){
$scope.onFileSelected();

if($scope.formData.reqType==="New To Bank"){
var payload = { 
proposer:$scope.loginuser,
reqType:$scope.formData.reqType,
PPACNo:$scope.uniqueId,
rational:$scope.formData.rational,
pu:$scope.formData.propUnit,
prod:$scope.formData.procName,
changes:$scope.formData.detailChng,
modi:$scope.formData.ratModif,
comp:$scope.formData.comp,
desc:$scope.formData.brfDesc,
status:$scope.status,
//attach:$scope.filename,
}
}
else {
var payload = { 
proposer:$scope.loginuser,
reqType:$scope.formData.reqType,
PPACNo:$scope.uniqueId,
rational:$scope.formData.rational,
pu:$scope.formData.propUnit,
prod:$scope.formData.procName,
changes:$scope.formData.detailChng,
modi:$scope.formData.ratModif,
comp:$scope.formData.comp,
desc:$scope.formData.brfDesc,
initDt:$scope.formData.initDt,
lastDt:$scope.formData.lastDt,
nxtDt:$scope.formData.nxtRDt,
status:$scope.status,
//attach:$scope.filename,
}
}

console.log(payload);


generateUniqueID(function(reqId) {
    console.log(reqId +"gg"); 
	

/*
reviewer
status
buHeadAct
attach
bu
history
ruStatus
initDt:$scope.formData.initDt,
lastDt:$scope.formData.lastDt,
nxtDt:$scope.formData.nxtRDt,
*/
    

const endpointUrl = "_api/web/lists/getByTitle('PPAC Request')/items";
// Send the request to create the list item

if ($scope.propId>0){
  payload["_metadata"]={
    "type":"SP>Data.PPAC%20RequestListItem"
  };
  Hyper.merge(endpoint+"("+$scope.propId+")",payload)
  .success(function(result){
    console.log(result);
  })
  .error(function(er){
    console.log("failed"+er.error.message.value);
  });
    
}
else{
Hyper.post(endpointUrl, payload)
  .success(function(result) {
	  
    alert("Request Submitted - Request ID: "+ reqId );
    console.log("ID", result.Id);
    $scope.propId = result.Id;
    $location.path("PU_Dashboard");
  })
  .error(function(error) {
    console.log("Error creating item: ", error);
  
      });
$scope.update=function(){
      // Update document library columns with reqType and PPACNo values
        var metadata = {
          type: 'SP.Data.NotesListItem'
        };
       $scope.updateData = {
          reqType: $scope.reqType1,
          PPACNo: $scope.PPACNo1,
          '__metadata': metadata
        };
        
        Hyper.merge('Notes', 50, $scope.updateData)
          .then(function() {
            $scope.attach.push($scope.nameWithoutExtension1); // Push filename to array
            
            console.log($scope.docId+"ji");
            console.log($scope.updateData);
            console.log($scope.PPACNo1+"hg");
            alert('File(s) updated successfully');
          })
          .catch(function(error) {
            console.error('Error updating document library columns:', error);
            alert('An error occurred while uploading the file(s). Please try again later.');
          });
        }
}

      });
}


$scope.status="";



//Draft and Raise 
$scope.onclick = function() {
  console.log($scope.formData.reqType);

  $scope.status="Awaiting BUH Approval";

 if($scope.formData.rational.length === 0 || $scope.formData.propUnit.length === 0 || $scope.formData.procName.length === 0 || $scope.formData.detailChng.length ===0 || $scope.formData.ratModif.length === 0 || $scope.formData.comp.length === 0 || $scope.formData.brfDesc.length === 0  ){
 

    alert("please fill all the fields");

    	if($scope.formData.rational.length === 0){
			$scope.rationalStdAlertMessage="Please Enter Rational for New To Bank"
		}
    	if($scope.formData.propUnit.length === 0){
			$scope.propUnitStdAlertMessage="Please Enter Proposing Unit Name"
		}
    	if($scope.formData.procName.length === 0){
			$scope.procNameStdAlertMessage="Please Enter Product / Process Name"
		}
    if($scope.formData.detailChng.length === 0){
			$scope.detailChngStdAlertMessage="Please Enter Change of Details"
		}
        	if($scope.formData.ratModif.length === 0){
			$scope.ratModifStdAlertMessage="Please Enter Rational Modification"
		}
    	if($scope.formData.comp.length === 0){
			$scope.compStdAlertMessage="Please Select Complexity or Not"
		}
    	if($scope.formData.brfDesc.length === 0){
			$scope.brfDescStdAlertMessage="Please Enter Brief Description"
		}
} 


if($scope.formData.reqType != "New to Bank" && $scope.formData.lastDt.length === 0 || $scope.formData.initDt.length === 0 || $scope.formData.nxtRDt.length === 0){
 if ($scope.formData.lastDt.length === 0) {
      $scope.lrdStdAlertMessage = "Please enter the Last Review Date";
    }
    if($scope.formData.initDt.length === 0){
			$scope.initDtStdAlertMessage="Please select the Initial Review Date"
		} 
    if($scope.formData.nxtRDt.length === 0){
			$scope.nxtRDtStdAlertMessage="Please select the Next Review Date"
		} 

}
 if($scope.formData.rational.length > 0 && $scope.formData.propUnit.length > 0 && $scope.formData.procName.length > 0 && $scope.formData.detailChng.length >0 && $scope.formData.ratModif.length > 0 && $scope.formData.comp.length > 0 && $scope.formData.brfDesc.length > 0 ){
$scope.save();

 } 
if($scope.formData.rational.length > 0 && $scope.formData.propUnit.length > 0 && $scope.formData.procName.length > 0 && $scope.formData.detailChng.length >0 && $scope.formData.ratModif.length > 0 && $scope.formData.comp.length > 0 && $scope.formData.brfDesc.length > 0 && $scope.formData.lastDt.length > 0 && $scope.formData.initDt.length > 0 && $scope.formData.nxtRDt.length > 0 ){
  $scope.save();
}

  }
  $scope.ondraft = function() {
  console.log($scope.formData.reqType);

  $scope.status="Draft";

    

$scope.save();



  }
});
