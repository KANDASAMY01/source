
PPAC.controller("ViewRequestCtrl", function($scope, $rootScope, $sce, $filter,$location, Hyper, SITE_SETTINGS, $q,$routeParams) {
	
	console.log('ViewRequestCtrl');
	$scope.loginuser = SITE_SETTINGS.userInfo.name;
$scope.profilePic="../_layouts/15/userphoto.aspx?accountname="+_spPageContextInfo.userLoginName;

	// $scope.commentsConfig = {
	// 	type: 'BU',
	// 	request:$routeParams.Id,
	// 	status:'Raised',
	// 	unit: 'Information Unit',
	// }
	
	
		
	// $scope.ruConfig = {
	// 	type: 'RU',
	// 	request:$routeParams.Id,
	// 	status:'BUHeadApproved',
	// 	unit: 'Information Unit',
	// }

	
	// $scope.singlePkr = {
	// 	selected: null,
	// 	multiple:false,
	// 	class:"my-peoplepicker-single"
	// }
	
	// $scope.multiPkr = {
	// 	selected: [],
	// 	multiple:true,
	// 	class:"my-peoplepicker-multi"
	// }

var itemId = $routeParams.Id;
console.log(itemId +"ji");
$scope.comments = [];



url = "/_api/web/lists/getbytitle('PPAC Request')/items(" + itemId + ")";

Hyper.get(url)
  .success(function(response) {
    $scope.id = response.d.ID;
    $scope.PPACNo = response.d.PPACNo;
    $scope.proposer = response.d.proposer;
    $scope.rational = $sce.trustAsHtml(response.d.rational);
    $scope.ratMod = $sce.trustAsHtml(response.d.modi);
    $scope.detChange = $sce.trustAsHtml(response.d.changes);
    $scope.comp = response.d.comp;
    $scope.req = response.d.reqType;
    $scope.prodName = response.d.prod;
    $scope.brfDes = $sce.trustAsHtml(response.d.desc);
    $scope.puName = response.d.pu;
    console.log($scope.PPACNo + "li");

    // Nest the second Hyper call inside the success callback of the first Hyper call
    var url_ = "/_api/web/lists/getbytitle('BU Queries')/items";
    Hyper.get(url_)
      .success(function(response) {
        for (var i = 0; i < response.d.results.length; i++) {
          var item = response.d.results[i];
          console.log(item.reqId);
          console.log("item.reqId:", item.reqId, typeof item.reqId);
          console.log("$scope.PPACNo:", $scope.PPACNo, typeof $scope.PPACNo);
          if (item.reqId === $scope.PPACNo) {
            
            $scope.comments = JSON.parse(item.Comment);
          }
        }
        console.log("$scope.comments:", $scope.comments);
        createCommentDivs();
      })
      .error(function(commentsError) {
        console.log(commentsError);
      });
  })
  .error(function(error) {
    console.log(error);
  });


function createCommentDivs() {
 for (var i = 0; i < $scope.comments.length; i++) {
    var comment = $scope.comments[i];
    var commentDiv = $('<div class="ms-2">' +
      '<div>' +
      '<div class="d-flex">' +
      '<div>' +
      '<p class="buh-name">' + comment.buhName + ',</p>' +
      '</div>' +
      '<div class="d-flex row tag">' +
      '<div class="p-1">' +
      '<div class="tag-cont d-flex ms-2">' +
      '<p class="tag-text">BUH</p>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '<div>' +
      '<p class="query-text">' + comment.commentText + '</p>' +
      '</div>' +
      '<div>' +
      '<p class="timestamp">' + comment.timestamp + ' - Comment</p>' +
      '</div>' +
      '</div>');

    if (i === $scope.comments.length - 1) {
      var buttonsDiv = $('<div class="buttons-container">' +
        '<button class="approve-button">Approve</button>' +
        '<button class="reject-button">Reject</button>' +
        '</div>');
      commentDiv.append(buttonsDiv);
    }

    $('#comments-container').append(commentDiv);
  }
}


$(document).ready(function () {
  $('#comment-input').keypress(function (e) {
    if (e.keyCode == 13) { // Enter key code
      e.preventDefault();
      createCommentDiv();
    }
  });

  function createCommentDiv() {
    var commentText = $('#comment-input').val();

    var comment = {
        PPACNo: $scope.PPACNo,
        buhName: $scope.loginuser,
        commentText: commentText,
        timestamp: getCurrentTimestamp()
      };
      $scope.comments.push(comment);

     url_ = "/_api/web/lists/getbytitle('BU Queries')/items";
    Hyper.get(url_)
  .success(function(response) {
    
    for(var i=0; i<response.d.results.length; i++){
    var item =response.d.results[i];
    if(item.reqId === $scope.PPACNo){
      $scope.Id = item.ID;
      console.log($scope.Id);
    }
    }
    $scope.upload();
  })
$scope.upload =function(){
var payload ={
  reqId: $scope.PPACNo,
  Comment: JSON.stringify($scope.comments),
}
console.log(payload);

  if($scope.Id>0){
    payload["__metadata"] ={
     "type": "SP.Data.BU_x0020_QueriesListItem"
    };
     Hyper.merge(url_ + "(" + $scope.Id +")", payload)
     .success(function(res){
       
       console.log(res);
     }).error(function(er){
        console.log(er);
       });
  }
  else{
    Hyper.post(url_ ,payload)
    .success(function(res){
      
        console.log(res);
     }).error(function(er){
        console.log(er,);
       });
    
  }
}
    $('.buttons-container').remove();
    var commentDiv = $('<div class="ms-2">' +
      '<div>' +
      '<div class="d-flex">' +
      '<div>' +
      '<p class="buh-name">' + $scope.loginuser +',</p>' +
      '</div>' +
      '<div class="d-flex row tag">' +
      '<div class="p-1">' +
      '<div class="tag-cont d-flex ms-2">' +
      '<p class="tag-text">BUH</p>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '<div>' +
      '<p class="query-text">' + commentText + '</p>' +
      '</div>' +
      '<div>' +
      '<p class="timestamp">' + getCurrentTimestamp() + ' - Comment</p>' +
      '<div class="buttons-container">' +
      '<button class="approve-button">Approve</button>' +
      '<button class="reject-button">Reject</button>' +
      '</div>' +
      '</div>' +
      '</div>');

    $('#comments-container').append(commentDiv[0]);
  $('#comment-input').val('');
  }

  $('#comments-container').on('click', '.approve-button', function (e) {
    
    console.log('Comment Approved:', $(this).closest('.ms-2'));
   
    $scope.status="In Review Unit"
    url="/_api/web/lists/getbytitle('PPAC Request')/items";
    var payload = {
    status: $scope.status
  };
  payload["__metadata"] ={
     "type": "SP.Data.PPAC_x0020_RequestListItem"
    };
     Hyper.merge(url+ "(" + $scope.id +")",payload )
     .success(function(res){
       console.log(res);
       alert("BUH Approved");
     }).error(function(er){
        console.log(er);
       });
        e.preventDefault();
  });

  $('#comments-container').on('click', '.reject-button', function (e) {
    console.log('Comment Rejected:', $(this).closest('.ms-2'));
    console.log($scope.comments);
    $scope.status="In Review Unit"
    url="/_api/web/lists/getbytitle('PPAC Request')/items";
    var payload = {
    status: $scope.status
  };
  payload["__metadata"] ={
     "type": "SP.Data.PPAC_x0020_RequestListItem"
    };
     Hyper.merge(url+ "(" + $scope.id +")",payload )
     .success(function(res){
       console.log(res);
       alert("BUH Approved");
     }).error(function(er){
        console.log(er);
       });
        e.preventDefault();
  });


  function getCurrentTimestamp() {
    var now = new Date();
    var day = now.getDate();
    var month = now.getMonth() + 1;
    var year = now.getFullYear();
    var hours = now.getHours();
    var minutes = now.getMinutes();

    return (
      (day < 10 ? '0' + day : day) + '/' +
      (month < 10 ? '0' + month : month) + '/' +
      year + ' ' +
      (hours < 10 ? '0' + hours : hours) + ':' +
      (minutes < 10 ? '0' + minutes : minutes)
    );
  }
});
});
