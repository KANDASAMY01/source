PPAC.controller("testCtrl", function($scope, $rootScope, $filter, Hyper, SITE_SETTINGS) {
	console.log("testCtrl");
});

