PPAC.service("Validation",function($q){
console.log('Test validation Service')
	var locType=''

	/********submit button validation**************/
	this.isValidation =function(fieldName,value,btnType){
	var isvalid=true;
	if(fieldName=='locType'){
				locType=value;
	}
		switch(fieldName+'-'+value+'-'+btnType){
		//customer Name
			case('cName'+'-'+""+'-'+'submit'):
			isvalid=false;
			break;
		// Address Line One
			case ('addressLine1'+'-'+""+'-'+'submit')||('addressLine1'+'-'+""+'-'+'reqAPI'):
			isvalid=false;
			break;
		//City Name
			case ('city'+'-'+""+'-'+'submit')||('city'+'-'+""+'-'+'reqAPI'):
			isvalid=false;
			break;
		//Province Name
			case ('provinceName'+'-'+""+'-'+'submit')||('provinceName'+'-'+""+'-'+'reqAPI'):
			isvalid=false;
			break;
		//Postal Code
			case ('postalCode'+'-'+""+'-'+'submit')||('postalCode'+'-'+""+'-'+'reqAPI'):
			isvalid=false;
			break;
		//Country Name
			case ('country'+'-'+""+'-'+'submit')||('country'+'-'+""+'-'+'submit'):
			isvalid=false;
			break;
		//Company Code
			case ('companyCode'+'-'+""+'-'+'submit'):
			isvalid=false;
			break;
		//Geo Accuracy Type
			case(locType=='fixedLoc'):
			case ('GeoAccuracyType'+'-'+""+'-'+'submit'):
			isvalid=false;
			break;
		//Latitude
			case(locType=='fixedLoc'):
			case ('latitude'+'-'+""+'-'+'submit'):
			isvalid=false;
			break;
		//Longitude
			case(locType=='fixedLoc'):
			case ('longitude'+'-'+""+'-'+'submit'):
			isvalid=false;
			break;
		//Verification Type
			case(locType=='fixedLoc'):
			case ('verification'+'-'+""+'-'+'submit'):
			isvalid=false;
			break;
		//Location Score
			case(locType=='fixedLoc'):
			case ('score'+'-'+""+'-'+'submit'):
			isvalid=false;
			break;
		//Verification Source
			case(locType=='fixedLoc'):
			case ('source'+'-'+""+'-'+'submit'):
			isvalid=false;
			break;
		//App ID
			case ('appId'+'-'+""+'-'+'submit'):
			isvalid=false;
			break;
		//location Types
			case ('locType'+'-'+""+'-'+'submit'):
			isvalid=false;
			break;
		//SRC Key ID Type
			case(locType=='customer'):
			case ('srckeyType'+'-'+""+'-'+'submit'):
			isvalid=false;	

				}
		  return isvalid;

		}
		
//number filed validation
 
   this.isCheckNumSize = function(fieldName,value){
   	var isCheckNumber  =true;
   	if(fieldName=='latitude'||fieldName=='longitude'){
   		var numberRex = new RegExp(/^\d{0,30}(\.\d{0,15})?$/)
   		 isCheckNumber =numberRex.test(value)
			
   	}
   	else if(fieldName=='score'){
   	var numberRex = new RegExp(/^\d{0,3}(\.\d{0,0})?$/)
   	 isCheckNumber =numberRex.test(value)

   	}
   	return isCheckNumber;
   	   
   }
   
   
	/*this.filedValidation =function(value){
	//check the Same alphabet repeated more than 3 consecutive times
			var rex= new RegExp(/([a-z\d])\1\1/i);
			var repAlpha=rex.test(value)
			console.log(!repAlpha)
	//Double space
			var spaceRex=new RegExp(/^\w+( \w+)*$/)
			var doubleSpce=spaceRex.test(value)
			console.log(doubleSpce)
	//check nubmer size
	var numberRex = new RegExp(/^\d{0,30}(\.\d{0,15})?$/)
	//var y=rex.test(value)
	}
	//this.filedValidation('shdhdshdfsddd  ')*/
	
	this.load = function(){
	var locType1=this.isValidation('locType',"fixedLoc",'submit');
	console.log(locType1)
	var cName=this.isValidation('cName',"",'submit');
	console.log('cName-submit',cName)
	var addressLine1=this.isValidation('addressLine1',"ddd",'submit');
	console.log('addressLine1-submit',addressLine1)
	var reqaddressLine1=this.isValidation('addressLine1',"",'reqAPI');
	console.log('addressLine1-submit',reqaddressLine1)
	var longitude=this.isValidation('longitude',"sdsdf",'submit');
	console.log('longitude-submit',longitude)

		
	}
		//this.load();
})