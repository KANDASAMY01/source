PPAC.controller("ORMConfigCtrl", function($scope, $rootScope, $filter, Hyper, SITE_SETTINGS,$timeout) {
	console.log("ORMConfigCtrl");
	$scope.config={
		id:0,
		reqType:"New To Bank",
		revCutOff:0,
		propCutOff:0,
		agree:0,
		reviewUnits:[],
		optReviewUnits:[],
	}
	$scope.allConfigs=[];
	$scope.selectedRequest=[];

	$scope.onChangeType = function(type){
		$scope.config.reqType = type;
		console.log("onChangeType");
		 $scope.selectedRequest =$scope.allConfigs.filter(item => item.reqType == $scope.config.reqType);
			if($scope.selectedRequest.length >0)
			{				
				$scope.config.id = $scope.selectedRequest[0].ID;
				$scope.config.revCutOff = $scope.selectedRequest[0].ru;
				$scope.config.propCutOff = $scope.selectedRequest[0].pu;
				$scope.config.agree = $scope.selectedRequest[0].agree;
				$scope.config.reviewUnits = $scope.selectedRequest[0].mRU.results.length >0 ? $scope.selectedRequest[0].mRU.results :[];
				$scope.config.optReviewUnits = $scope.selectedRequest[0].oRU.results.length >0 ? $scope.selectedRequest[0].oRU.results :[]
			}
			else{
				$scope.config.id = 0;				
				$scope.config.revCutOff = 0;
				$scope.config.propCutOff = 0;
				$scope.config.agree = 0;
			}
		console.log($scope.config,"$scope.config");
	}

	$scope.removeReviewUnit = function(reviewUnit){
		console.log("removeReviewUnit",reviewUnit);
		let temp = $scope.config.reviewUnits.find(item => item.Id === reviewUnit.Id);
		let index = $scope.config.reviewUnits.indexOf(temp);
		if (index !== -1) {
  			$scope.config.reviewUnits.splice(index, 1); // Removes the object at index 1
		}
	}

	$scope.removeOptReviewUnit = function(optReviewUnit){
		console.log("removeOptReviewUnit",optReviewUnit);
		let temp = $scope.config.optReviewUnits.find(item => item.Id === optReviewUnit.Id);
		let index = $scope.config.optReviewUnits.indexOf(temp);
		if (index !== -1) {
  			$scope.config.optReviewUnits.splice(index, 1); // Removes the object at index 1
		}
	}

	$scope.getConfigs= function(){		
      //$scope.spinner = true;
      Hyper.get(
        "_api/Web/Lists/getByTitle('PPAC Configuration')/items?$select=*,mRU/Id,mRU/Title,oRU/Id,oRU/Title&$expand=mRU,oRU&$top=5000"
      )
        .success(function (res) {
          console.log(res.d.results);
          if (res.d.results.length > 0) {
            $scope.allConfigs = res.d.results;
			console.log("$scope.allConfigs", $scope.allConfigs);
			$scope.onChangeType($scope.config.reqType);								
		  }		  
        })
        .error(function (er) {
          console.log("error:", er);
          //$scope.spinner = false;
        });
	}

	$scope.onSubmit= function(){
		var payload={
				"reqType":$scope.config.reqType,
				"ru":Number($scope.config.revCutOff),
				"pu":Number($scope.config.propCutOff),
				"agree":Number($scope.config.agree),
				"mRUId": $scope.config.reviewUnits.map(i=>Number(i.Id)),
				"oRUId": $scope.config.optReviewUnits.map(i=>Number(i.Id)),
			}

		if($scope.selectedRequest.length > 0) // update
		{
			payload["__metadata"] = {
          	type: "SP.Data.PPAC_x0020_ConfigurationListItem",
        	};
			payload["mRUId"] = {
            	"results":$scope.config.reviewUnits.map(i=>Number(i.Id))
            };
			payload["oRUId"] = {
            	"results":$scope.config.optReviewUnits.map(i=>Number(i.Id))
            };
			Hyper.merge(
          "_api/Web/Lists/getByTitle('PPAC Configuration')/items(" +
            $scope.config.id +
            ")",
          payload
        )
          .success(function (result) {
             //$scope.spinner = true;             
            $scope.getConfigs();
          })
          .error(function (er) {
            console.log("error:", er);            
            //$scope.spinner = false;
          });
		}
		else{									// add
			
			Hyper.post(
          "_api/Web/Lists/getByTitle('PPAC Configuration')/items",
          payload
        )
          .success(function (result) {   
              //$scope.spinner = false;            
			  $scope.getConfigs();
          })
          .error(function (er) {
            console.log("error:", er);
            //$scope.spinner = false;            
          });
		}

	}

	

	//  $scope.initPeoplePicker = function () {
    //   console.log("initPeoplePicker");
    //   var oldhtml = "";
    //   $('div [id^="peoplePickerTo"]').html(oldhtml);

    //   $timeout(function () {
    //     angular.element("#peoplePickerTo").spPeoplePicker(function (res) {
    //       // console.log(res);
    //       $scope.OnUserResolvedClientScript(res, "resPerson");
    //     }, false);
    //     angular.element("#peoplePickerTo_TopSpan").addClass("form-control");
    //     $timeout(function () {
    //       angular
    //         .element("#peoplePickerTo_TopSpan_EditorInput")
    //         .addClass("people-picker");
    //       if ($scope.formData.resPerson) {
    //         var email =
    //           $scope.formData.resPerson.EMail ||
    //           $scope.formData.resPerson.WorkEmail ||
    //           $scope.formData.resPerson.UserName;
    //         $scope.SetAndResolvePeoplePicker(email, "peoplePickerTo_TopSpan");
    //       }
    //     //   $(".sp-autoFill-scroll").click(function(e){e.preventDefault();e.stopPropagation();});
    //     //    $("#peoplePickerTo_TopSpan_WaitImage").click(function(e){e.preventDefault();e.stopPropagation();});
    //     //   $(".ms-core-menu-item").click(function(e){e.preventDefault();e.stopPropagation();});
    //     //   $(".ms-core-menu-label").click(function(e){e.preventDefault();e.stopPropagation();});
    //     //   $(".ms-core-menu-sublabel").click(function(e){e.preventDefault();e.stopPropagation();});
    //     //   $(".ms-core-menu-link").click(function(e){e.preventDefault();e.stopPropagation();});
    //     //   $(".sp-peoplepicker-delImage").click(function(e){e.preventDefault();e.stopPropagation();});

    //     //   $(".sp-autoFill-scroll").mousedown(function(e){e.preventDefault();e.stopPropagation();});
    //     //   $(".ms-core-menu-item").mousedown(function(e){e.preventDefault();e.stopPropagation();});
    //     //   $(".ms-core-menu-label").mousedown(function(e){e.preventDefault();e.stopPropagation();});
    //     //   $(".ms-core-menu-sublabel").mousedown(function(e){e.preventDefault();e.stopPropagation();});
    //     //   $(".ms-core-menu-link").mousedown(function(e){e.preventDefault();e.stopPropagation();});
    //     //   $(".sp-peoplepicker-delImage").mousedown(function(e){e.preventDefault();e.stopPropagation();});

    //     //   $(".sp-autoFill-scroll").mouseover(function(e){e.preventDefault();e.stopPropagation();});
    //     //   $(".ms-core-menu-item").mouseover(function(e){e.preventDefault();e.stopPropagation();});
    //     //   $(".ms-core-menu-label").mouseover(function(e){e.preventDefault();e.stopPropagation();});
    //     //   $(".ms-core-menu-sublabel").mouseover(function(e){e.preventDefault();e.stopPropagation();});
    //     //   $(".ms-core-menu-link").mouseover(function(e){e.preventDefault();e.stopPropagation();});
    //     //   $(".sp-peoplepicker-delImage").mouseover(function(e){e.preventDefault();e.stopPropagation();});
    //     }, 100);
    //   }, 100);
    // };

	// $scope.SetAndResolvePeoplePicker = function(userAccountName, divID) {
  	// 	//console.log(userAccountName, divID);
	// 	SP.SOD.loadMultiple(['sp.core.js', 'sp.runtime.js', 'sp.js', 'autofill.js', 'clientpeoplepicker.js', 'clientforms.js', 'clienttemplates.js'],       function() {
	// 	  	var peoplePickerDiv = $("[id$="+divID+"][title='Enter a name or email address...']");
	// 		var peoplePickerEditor = peoplePickerDiv.find("[title='Enter a name or email address...']");		
	// 		var spPeoplePicker = SPClientPeoplePicker.SPClientPeoplePickerDict[divID];
			
	// 		if (peoplePickerEditor) {
	// 			peoplePickerEditor.val(userAccountName);
	// 		}
	// 		if (spPeoplePicker) {
	// 			spPeoplePicker.AddUnresolvedUserFromEditor(true);
	// 		}
	// 	});
	// } 

	// $scope.OnUserResolvedClientScript = function (userKey, obj) {
    //   try {
    //     var temp = userKey;
    //     console.log("User Details", temp);
    //     if (userKey.length > 0) {
    //       var addedUser = userKey[userKey.length - 1];
    //       // console.log('if-', addedUser);
    //       var usr = addedUser.Key.split("|membership|");
    //       $scope.updateListData(usr[1] || usr[0], obj);
    //     } else {
    //       $scope.formData[obj] = null;
    //       //console.log('else-', $scope.selectedUser);
    //     }
    //   } catch (e) {
    //     //console.log(e);
    //   }
    // };

	// $scope.updateListData = function (user, obj) {
    //   var url = "_vti_bin/listdata.svc/UserInformationList?$select=Id,Name,UserName&$filter=UserName eq '" + user + "'";

    //   try {
    //     Hyper.get(url).then(
    //       function success(resp) {
    //         //console.log(user,list,index,$scope.ownerPic);
    //         if (resp.data.d.results.length >= 1) {
    //           console.log("Success - ", resp.data.d.results[0]);
    //           $scope.formData[obj] = resp.data.d.results[0];
    //           console.log('selected', $scope.formData[obj]);
    //             /*var ele =  $('a[title="Remove person or group '+resp.data.d.results[0].Name+'"]');

    //             if (ele && ele.length>0) {
    //               document.getElementById(ele[0].id).addEventListener('click', function(e) {
    //                   console.log("clicked", e);
    //                   e.preventDefault();
    //                   e.stopPropagation();
    //               });
    //             }*/
              
    //         } else {
    //           $scope.ensureUser(user, obj);
    //         }

    //         $(".sp-peoplepicker-delImage").click(function(e){e.stopPropagation();});

    //       },
    //       function error(resp) {
    //         //console.log("Error - ", resp)
    //       }
    //     );
    //   } catch (e) {
    //     // console.log('exception', e);
    //   }
    // };

	// $scope.ensureUser = function (user, obj) {
    //   if (user != null && user != undefined && user.trim().length > 0) {
    //     var url = "_api/web/ensureuser";
    //     var data = "{ 'logonName':'i:0#.f|membership|" + user + "'}";
    //     var headers = {
    //       "Content-Type": "application/json;odata=verbose",
    //       Accept: "application/json;odata=verbose",
    //       Authorization:
    //         "Bearer " + document.getElementById("__REQUESTDIGEST").value,
    //     };
    //     Hyper.post(url, data, headers).then(
    //       function success(resp) {
    //         $scope.updateListData(user, obj);
    //       },
    //       function error(resp) {
    //         $scope.formData[obj] = null;
    //         // console.log("Error - ", resp)
    //         alert("The selected person cannot be added.");
    //       }
    //     );
    //   }
    // };

	$scope.initPeoplePicker = function(eleId, field, isMulti, value) {
    	var oldhtml = '';
    	$('div [id^="'+eleId+'"]').html(oldhtml);

        $timeout(function(){
				angular.element('#'+eleId).spPeoplePicker(function(res) {
				    $scope.OnUserResolvedClientScript(res, field, isMulti, eleId);
				},isMulti);
				angular.element( "#"+eleId+"_TopSpan" ).addClass( "form-control" ); 
                $timeout(function(){ 
	               	angular.element( "#"+eleId+"_TopSpan_EditorInput" ).addClass("people-picker");  
	               	if (value.length > 0) {
	               		for (var i=0;i<value.length;i++) {
							$scope.SetAndResolvePeoplePicker(value[i],eleId+'_TopSpan', isMulti);
	               		}
					}            
	            },100);	            
        }, 100);
    }
    
    $scope.SetAndResolvePeoplePicker = function(userAccountName, divID, isMulti) {
  		//console.log(userAccountName, divID);
		SP.SOD.loadMultiple(['sp.core.js', 'sp.runtime.js', 'sp.js', 'autofill.js', 'clientpeoplepicker.js', 'clientforms.js', 'clienttemplates.js'], function() {
		  	
		  	var titleTxt = 'Type Name/Email';
		  	var peoplePickerDiv = $("[id$="+divID+"][title='"+titleTxt +"']");
			var peoplePickerEditor = peoplePickerDiv.find("[title='"+titleTxt +"']");		
			var spPeoplePicker = SPClientPeoplePicker.SPClientPeoplePickerDict[divID];
			
			if (peoplePickerEditor) {
				peoplePickerEditor.val(userAccountName);
			}
			if (spPeoplePicker) {
				spPeoplePicker.AddUnresolvedUserFromEditor(true);
			}
		});
	}
	
	$scope.OnUserResolvedClientScript = function(userKey, obj, isMulti, eleId) {
        try {
            var temp = userKey;
            $scope.formData[obj]= isMulti ? [] : null;
            $scope.formData[obj+"Id"]= isMulti ? [] : null;
            if (userKey.length > 0) {
            	var userIds = [];
            	angular.forEach(userKey, function(user, index) {
            		// console.log(user, index);
            		var usr = user.Key.split('|membership|')
            		var email =  usr[1]|| usr[0];
            		if (userIds.indexOf(email)==-1) {
            			userIds.push(email);
	                	$scope.updateListData(email, obj, isMulti, eleId);
            		}else {
            			$('a[title="Remove person or group '+user.DisplayText+'"]')[0].click();
            		}  
            	});
               
            }
        } catch (e) {
            //console.log(e);
        }
    }

    $scope.updateListData = function(user, obj, isMulti, eleId) {
        var url = "_vti_bin/listdata.svc/UserInformationList?$select=Id,Name,UserName&$filter=UserName eq '" + user + "'";
        try {
            Hyper.get(url)
                .then(function success(resp) {
                    if (resp.data.d.results.length >= 1) {
                    	if (isMulti) {
                    		$scope.formData[obj].push(resp.data.d.results[0]);
                    		$scope.formData[obj+"Id"].push(resp.data.d.results[0].Id)
                    	} else {
                    		$scope.formData[obj] = resp.data.d.results[0];
                    		$scope.formData[obj+"Id"]= resp.data.d.results[0].Id;
                    	}
                    } else {
                        $scope.ensureUser(user,obj, isMulti, eleId);
                    }

                }, function error(resp) {
                    //console.log("Error - ", resp)
                });
        } catch (e) {
           // console.log('exception', e);
        }
    }


    $scope.ensureUser = function(user, obj, isMulti, eleId) {
        if (user != null && user != undefined && user.trim().length > 0) {
            var url = "_api/web/ensureuser";
            var data = "{ 'logonName':'i:0#.f|membership|" + user + "'}"
            Hyper.post(url, data)
            .then(function success(resp) {
                $scope.updateListData(user, obj, isMulti, eleId);
            },
            function error(resp) {
               	alert('The selected person cannot be added.');
            });
        }
    }

	$scope.getConfigs();
	//  $scope.initPeoplePicker();
	$scope.initPeoplePicker("peoplePickerRUnits", "multiPeople", true, []);
});

