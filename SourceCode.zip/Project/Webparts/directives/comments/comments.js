PPAC.directive("comments", function(Hyper, SITE_SETTINGS) {
	return  {
		restrict:'E',
		templateUrl:'../Style Library/PPAC/Webparts/directives/comments/comments.html',
		replace:true,
		scope: {
			type:'=',
			request: '=',
			status: '=',
			unit: '='
		},
		link:function(scope, ele , attributes) {
			console.log("------comments directive--------");
			console.log("request", scope.request);
			console.log("status", scope.status);
			console.log("--------------------------------");
			scope.userInfo = SITE_SETTINGS.userInfo;
			scope.role = scope.userInfo.loginRole;
			
			scope.config = {
				isChildApplicable : false,
				canReply : true,
				cuttOffExceed:false,
				comment:''
			}
			var BUCommentsList = "BU Queries";
			var RUCommentsList = "RU Queries";
			var listName = scope.type == 'BU' ? BUCommentsList : RUCommentsList;
			
			scope.config.isChildApplicable = scope.type == 'RU';
			scope.config.canReply = (scope.type == 'BU' && scope.status=='Raised') || (scope.type == 'RU' && scope.status=='BUHeadApproved');
			// Draft/Raised/BUHeadApproved/BUHeadDeclined/RUApproved/RURejected/CMApproved/CMRejected/SHApproved/SHRejected/Approved/Rejected/Deferred
			scope.comments = {
				total:[],
				pending:[],
				agree:[],
				committee:[]
			};
			
			scope.selected = {
				status: 'total',
				comment: -1
			}
			
			
			scope.commentsList = [];
			scope.sendReply = function(comment) {
				
				var txt = !comment? scope.config.comment: comment.reply;
				if (!txt || (txt  && txt.trim().length == 0)) {
					alert("Please fill in your comment");
					return;
				}
				var payload = { 
					reqId:scope.request,
					Comment: txt,
					Title:scope.role,
				}
				
				if (scope.config.isChildApplicable) {
					if (comment && comment.Id) {
						payload["pId"] = comment.Id.toString();
					} else {
						payload["status"] = "Pending";

					}
					if (scope.unit && scope.role != "PU") {
						payload["Title"] = scope.unit;
					}
				}
				
				
				// Pending/Agree/Take to Committee

				var url = "_api/web/lists/getByTitle('"+listName+"')/items";
	
				Hyper.post(url, payload)
				.success(function(result) {
					scope.getComments();
				})
				.error(function(error) {
					console.log("Error creating item: ", error);
				});
			}
			
			scope.getComments = function(id) {
				scope.config.comment = "";
				scope.comments = {
					total:[],
					pending:[],
					agree:[],
					committee:[]
				};
				
				scope.commentsList = [];
				
				var url = "_api/web/lists/getByTitle('"+listName+"')/items?&$select=*,Author/Id,Author/Title&$expand=Author&$top=5000&$filter = reqId eq '"+scope.request+"'";
				
				Hyper.get(url )
			    .success(function(data){
									        
			       if (data.d.results.length > 0) {
					
						var byParent = _.groupBy(data.d.results, 'pId');
						console.log('byParent ', byParent);
						
						var cList =  byParent["undefined"]||byParent["null"];
								       				       	
						for (var i=0;i<cList.length;i++) {
							cList[i].responses = byParent[cList[i].Id] || [];					
						}
				       	
						scope.comments.total = cList;
				       	
				       	var byStatus = _.groupBy(cList, 'status');
						console.log('byStatus ', byStatus);
						
				       	scope.comments.pending= byStatus.Pending || [];
				   		scope.comments.agree= byStatus.Agree|| [];
				   		scope.comments.committee= byStatus.Committee|| [];
				       	
				       	scope.onSetStatus();
				       	
			       	}
			       
			    })
			    .error(function(error) {
					console.log("Error creating item: ", error);
				});

    		}
    		
    		scope.getComments();
			
			scope.onSetStatus = function(status) {
				if (status) {
					scope.selected.status = status;
					scope.selected.comment = -1;
				}
				
				scope.commentsList = angular.copy(scope.comments[scope.selected.status]);
			}
			
			scope.onAction = function(id, status) {
				
				var url = "_api/web/lists/getByTitle('"+listName+"')/items("+id+")";
				
				var payload = { 
					"status":status,
					"__metadata": {
						"type": "SP.Data.RU_x0020_QueriesListItem" //"SP.Data."+listName.replace(/ /g,'_x0020_')+"ListItem"
					}
				}
	
				Hyper.merge(url , payload)
				.success(function(result) {
					scope.getComments();
				})
				.error(function(error) {
					console.log("Error creating item: ", error);
				});
			}

			
		}
		
	}
})